package FileIO;

import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class primitivedata {

	public static void main(String[] args) throws IOException{
		FileInputStream fis=new FileInputStream("C:/Users/pkomarra/Desktop/New Text Document.txt");
		FileOutputStream fos=new FileOutputStream("C:/Users/pkomarra/Desktop/Copy.txt");
		
		DataOutput out=new DataOutputStream(fos);
		int i=10;
		double d=45.34;
		boolean b=false;
		String str="Hello World ...!!!";
		
		DataInputStream in=new DataInputStream(fis);
		int num=in.readInt();
		double dvalue=in.readDouble();
		boolean bool=in.readBoolean();
		String s=in.readUTF();
		
		System.out.println(num+" "+dvalue+" "+bool+" "+s);
	}

}
