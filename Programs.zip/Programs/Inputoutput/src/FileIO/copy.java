package FileIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class copy {

	public static void main(String[] args) throws IOException{
		FileInputStream fis=new FileInputStream("C:/Users/pkomarra/Desktop/New Text Document.txt");
		FileOutputStream fos=new FileOutputStream("C:/Users/pkomarra/Desktop/Copy.txt");
		/*int d;
		while((d=fis.read())!=-1){
			System.out.print((char)d);
			fos.write(d);
		}*/
		byte[] buffer = new byte[fis.available()];
		fis.read(buffer);
		fis.read(buffer);
		fos.write(buffer);
		System.out.println("File Copied Successfully");
		fis.close();
		fos.close();
	}
}
