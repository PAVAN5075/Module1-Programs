package FileIO;

import java.io.FileInputStream;
import java.io.IOException;

public class App {
	public static void main(String []args) throws IOException{
	FileInputStream fis=new FileInputStream("C:/Users/pkomarra/Desktop/New Text Document.txt");
	/*int d;
	while((d=fis.read())!=-1){
		System.out.print((char)d);
	}*/
	byte[] buffer = new byte[fis.available()];
	fis.read(buffer,3,5);
	System.out.println(new String(buffer));
	fis.close();
}
	
}
