package FileIO;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class App2 {

		public static void main(String[] args) throws IOException{
			FileInputStream fis=new FileInputStream("C:/Users/pkomarra/Desktop/New Text Document.txt");
			FileOutputStream fos=new FileOutputStream("C:/Users/pkomarra/Desktop/Copy.txt");
			
			BufferedInputStream bis=new BufferedInputStream(fis);
			BufferedOutputStream bos=new BufferedOutputStream(fos);
			
			int d;
			while((d=bis.read())!=-1){
				System.out.print((char)d);}
			
			System.out.println("File Copied Successfully");
			bis.close();
			bos.close();
			fis.close();
			fos.close();
	}

}
