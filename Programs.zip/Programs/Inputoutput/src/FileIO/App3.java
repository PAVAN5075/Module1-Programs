package FileIO;

import java.io.IOException;

public class App3 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder();
		 
		int d;
		while((d=System.in.read())!='\n'){
			sb.append((char)d);
		}
		System.out.println("You have Entered: "+sb);
	}

}
