package FileIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class App5 {

	public static void main(String[] args) throws IOException{
		Employee emp= new Employee();
		emp.setId(2020);
		emp.setName("KPS");
		emp.getGender();
		emp.setAge(21);
		emp.setSalary(20000);
		
		FileOutputStream out=new FileOutputStream("C:/Users/pkomarra/Desktop/emp");
		ObjectOutputStream obj=new ObjectOutputStream(in);
		Employee e=(Employee)obj.readObject();
		obj.writeObject(emp);
		System.out.println("Successful");
		
		
		
		
		
		
		
		
		
		
	}

}
