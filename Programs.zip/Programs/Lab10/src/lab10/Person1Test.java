package lab10;

import static org.junit.Assert.*;

import org.junit.Test;

public class Person1Test {

	@Test
	public void test() {
		Person1 p=new Person1("Pavan", "Sudhakar", 'M');
		assertEquals("Bhanu", p.getFirstname());
		//fail("Not yet implemented");
		System.out.println(p);
		assertEquals(p, p.toString());
	}

}
