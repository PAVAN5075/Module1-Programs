package lab10;

public class Date {
	int Day;
	int Month;
	int Year;
	public int getDay() {
		return Day;
	}
	public void setDay(int day) {
		Day = day;
	}
	public int getMonth() {
		return Month;
	}
	public void setMonth(int month) {
		Month = month;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	@Override
	public String toString() {
		return "Date [Day=" + Day + ", Month=" + Month + ", Year=" + Year + "]";
	}
	public Date(int day, int month, int year) {
		super();
		this.Day =day;
		this.Month = month;
		this.Year = year;
	}
	public static void main(String[] args) {
		Date d=new Date(14, 01, 1997);
		System.out.println(d.getDay());
		System.out.println(d.getMonth());
		System.out.println(d.getYear());
	}

}
