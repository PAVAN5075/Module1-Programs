package lab10;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonTest {

	@Test
	public void test() {
		System.out.println("from test");
		Person p=new Person("Robert", "King");
		assertEquals("Robert King", p.getFullname());
		//fail("Not yet implemented");
	}
	@Test(expected=IllegalArgumentException.class)
	public void testNullsInName(){
		System.out.println("Testing Exceptions");
		Person p1=new Person(null, null);
	}

}
