package lab10;

public class Person1 {
	@Override
	public String toString() {
		return "Person1 [firstname=" + firstname + ", lastname=" + lastname
				+ ", gender=" + gender + "]";
	}

	public Person1(String firstname, String lastname, Character gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Character getGender() {
		return gender;
	}

	public void setGender(Character gender) {
		this.gender = gender;
	}

	String firstname;
	String lastname;
	Character gender;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
