package lab10;

public class Person {
	public String getFirstname() {
		return firstname;
	}
	public String getLastname() {
		return lastname;
	}
	private String firstname;
	private String lastname;
	public  Person(String fname,String lname){
		if(fname==null&&lname==null){
			throw new IllegalArgumentException("Both names cannot be null");
		}
		this.firstname=fname;
		this.lastname=lname;
	}
	public String getFullname(){
		String first=(this.firstname!=null)?this.firstname:"?";
		String last=(this.lastname!=null)?this.lastname:"?";
		return first+" "+last;	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person("a", "b");
		System.out.println(p.getFirstname());
	}

}
