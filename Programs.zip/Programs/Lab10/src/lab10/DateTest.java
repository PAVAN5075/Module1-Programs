package lab10;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
		Date d=new Date(14, 01, 1997);
		assertEquals(14, d.getDay());
		assertEquals(01, d.getMonth());
		assertEquals(1997, d.getYear());
	}
	

}
