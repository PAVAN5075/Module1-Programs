 package com.cg.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Scanner sc= new Scanner(System.in);
			/*System.out.println("Enter Gender");
			String g=sc.nextLine();*/
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
				Connection con=DriverManager.getConnection(url, "system", "orcl11g");
				
				/*System.out.println("Enter Name");
				String name=sc.nextLine();
				System.out.println("Enter Gender");
				String gender=sc.nextLine();
				System.out.println("Enter Age");
				int age=Integer.parseInt(sc.nextLine());
				System.out.println("Enter Salary");
				double sal=Double.parseDouble(sc.nextLine());*/
				/*Statement stat=con.createStatement();
				ResultSet rs=stat.executeQuery("SELECT * FROM employee");*/
				PreparedStatement s1 =con.prepareStatement("UPDATE employee set salary=salary+100 WHERE eno=1002");
				PreparedStatement s2 =con.prepareStatement("UPDATE employee set salary=salary-100 WHERE eno=1004");
				s1.executeUpdate();
				s2.executeUpdate();
				
				con.rollback();
				
				
				/*stat.setInt(1, id);
				stat.setString(2, name);
				stat.setString(3, gender);
				stat.setInt(4, age);
				stat.setDouble(5, sal);*/
				
				/*int res=stat.executeUpdate();
				System.out.println("Row Inserted "+res);*/
				
				s1.close();
				s2.close();
				con.close();
		}
				
				catch (SQLException | ClassNotFoundException e) {
					
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}

}
