package Bank;

import java.util.Random;
import java.util.Scanner;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String name=sc.nextLine();
		int accno;
		int age=sc.nextInt();
		accno=(int) ((int)12347*Math.random());
		if(age<15)
		{
			try{
				throw new Exception("Age is lessthan 15, cannot open a bank account");
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		else{
			System.out.println("Name: "+name);
			System.out.println("Account No.: "+accno);
			System.out.println("Age: "+age);
		}

	}

}
