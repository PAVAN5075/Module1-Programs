package Employee;

import java.util.Scanner;

public class Employeename {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String fname=sc.nextLine();
		String lname=sc.nextLine();
		if(fname==null && lname==null)
		{
			try {
				throw new Exception("Name field is null");
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
		else{
			System.out.println(fname + lname);
		}
	}

}
