package com.cg.eis.exception;

import java.util.Scanner;

public class Employee {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int salary=sc.nextInt();
		if(salary<3000)
		{
		try {
			throw new EmployeeException("Salary is lessthan 3000");
			}
			catch(EmployeeException e){
				System.out.println(e.getMessage());
			}
		}
		else{
			System.out.println("Salary is morethan 3000");
		}
	}
}

