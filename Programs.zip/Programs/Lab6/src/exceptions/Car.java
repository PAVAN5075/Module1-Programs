package exceptions;

public class Car {
void readDataFromSensor(){
	System.out.println("File is open");
	try{
		System.out.println("Data is read");
	}
	catch(Exception e){
		System.out.println("Plz Wait");
	}
	
}
}
