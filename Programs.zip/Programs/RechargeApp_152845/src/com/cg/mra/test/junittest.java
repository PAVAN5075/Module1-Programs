package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.exception.RechargeException;

public class junittest {
	AccountDao dao;
	@Test
	public void testrechargeAmount() throws RechargeException {
		
		assertNull(dao.getAccountDetails("9932018556"));
	}

}
