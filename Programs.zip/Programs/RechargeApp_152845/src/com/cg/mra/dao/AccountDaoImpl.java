package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;
import com.cg.mra.db.AccountDB;
import com.cg.mra.exception.RechargeException;

public class AccountDaoImpl implements AccountDao {
	HashMap<String, Account> accMap=AccountDB.getDb();
	
	@Override
	public Account getAccountDetails(String mobileNo) throws RechargeException {
		Account acc=accMap.get(mobileNo);
		if(acc==null){
			throw new RechargeException("ERROR: Given Account Id Does Not Exists");
		}
		return acc;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws RechargeException {
		
		
		return 0;
	}

}
