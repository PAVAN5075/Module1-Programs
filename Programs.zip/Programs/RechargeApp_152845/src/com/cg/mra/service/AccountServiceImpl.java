package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.RechargeException;

public class AccountServiceImpl implements AccountService {
	
	AccountDao accountDao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) throws RechargeException {
		// TODO Auto-generated method stub
		return accountDao.getAccountDetails(mobileNo);
	}


	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws RechargeException {
		// TODO Auto-generated method stub
		return 0;
	}
	
private boolean validateMobile(String mobileNo) throws RechargeException{
		
		if(!mobileNo.matches("\\d{10}")){
			throw new RechargeException("Mobile Number should contain 10 Digits");
		}
		
		return true;
		
	}

@SuppressWarnings("unused")
private boolean validateRechargeAmount(double rechargeAmount) throws RechargeException{
	
	if(rechargeAmount>0){
		throw new RechargeException("Invalid Recharge Amount");
	}
	
	return true;
	
}


@Override
public boolean validateInputs(Account acc) throws RechargeException {
	
	if(validateMobile(acc.getMobileNo())){
		return true;
	}
	return false;
}

}
