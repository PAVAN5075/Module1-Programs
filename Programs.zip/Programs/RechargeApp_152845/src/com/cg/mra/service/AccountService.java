package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.RechargeException;


public interface AccountService {
	
	Account getAccountDetails(String mobileNo) throws RechargeException;
	
	boolean validateInputs(Account acc) throws RechargeException;
	
	int rechargeAccount(String mobileNo, double rechargeAmount) throws RechargeException;
	
}
