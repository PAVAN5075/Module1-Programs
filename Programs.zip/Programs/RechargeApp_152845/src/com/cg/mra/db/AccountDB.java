package com.cg.mra.db;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public class AccountDB {
	
	
	private static HashMap<String, Account> accDb=new HashMap<String, Account>();
	
	public static HashMap<String,Account>getDb(){
		return accDb;
	}
		static{
			
			accDb.put("9922943943", new Account("9922943943","Prepaid","Mark",500));
			accDb.put("9932012345", new Account("9932012345","Prepaid","Manish",300));
			accDb.put("9988776655", new Account("9988776655","Postpaid","Sara",500));
		}
	
}
