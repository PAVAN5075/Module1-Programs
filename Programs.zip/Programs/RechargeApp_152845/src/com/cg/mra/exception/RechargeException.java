package com.cg.mra.exception;

public class RechargeException extends Exception{
	public RechargeException(){
		super();
	}
	public RechargeException(String message){
		super(message);
	}
}
