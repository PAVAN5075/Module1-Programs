package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.RechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	Scanner sc=new Scanner(System.in);
	AccountService service =new AccountServiceImpl();
	public static void main(String[] args) {
		
			// TODO Auto-generated method stub
			System.out.println("======== Recharge App ========");
			MainUI c=new MainUI();
			String option="";
			while(true){
				System.out.println("1. Account Balance Enquiry");
				System.out.println("2. Recharge Amount");
				System.out.println("3. Exit");
				System.out.println("Enter your Choice");
				option=c.sc.nextLine();
				switch(option){
				case "1":
					c.getAccountDetails();
					break;
				case "2":
					c.rechargeAccount();
					break;
				case "3":
					System.out.println("Thank You...!!!");
					System.exit(0);
					break;
				default:
					System.out.println("Please Enter option between 1 to 3");
					break;
				}
			}
	}
	
	private void getAccountDetails(){
		System.out.print("Enter the Mobile Number");
		String mobileNo=sc.nextLine();
		
		try {
			Account acc= service.getAccountDetails(mobileNo);
			System.out.println("Your Current Balance is Rs."+acc.getAccountBalance());
		} catch (RechargeException e) {
			System.out.println("");
			System.err.println(e.getMessage());
			System.out.println();
		}
	}
	
	private void rechargeAccount(){
		System.out.println("Enter Mobile Number");
		String mobileNo=sc.nextLine();
		System.out.println("Enter Recharge Amount");
		double rechargeAmount=sc.nextDouble();
		try {
			Account acc= service.getAccountDetails(mobileNo);
			double totalamount=rechargeAmount+acc.getAccountBalance();
			System.out.println("Your Account Recharged Successfully");
			System.out.println("Hello "+acc.getCustomerName()+", Available Balance is "+totalamount);
		} catch (RechargeException e) {
			System.out.println("");
			System.err.println(e.getMessage());
			System.out.println();
		}
	}
	
}
