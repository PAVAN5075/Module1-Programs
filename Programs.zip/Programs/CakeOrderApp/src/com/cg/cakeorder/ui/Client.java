package com.cg.cakeorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.cakeorder.bean.CakeRequest;
import com.cg.cakeorder.exception.CakeOrderException;
import com.cg.cakeorder.service.CakeOrderService;
import com.cg.cakeorder.service.ICakeOrderService;

public class Client {
	ICakeOrderService cakeOrderService=new CakeOrderService();
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("======== Cake Order App ========");
			Client c=new Client();
			String option="";
			while(true){
				System.out.println("1. Place Order");
				System.out.println("2. Display Order");
				System.out.println("3. Exit");
				System.out.println("Enter your Choice");
				option=c.sc.nextLine();
				switch(option){
				case "1":
					c.makeRequest();
					break;
				case "2":
					c.displayOrderDetails();
					break;
				case "3":
					System.out.println("Thank You...!!!");
					System.exit(0);
					break;
				default:
					System.out.println("Please Enter option between 1 to 3");
					break;
				}
			}

		}
		
		public void makeRequest(){
			CakeRequest req=new CakeRequest();
			System.out.println("Enter Customer Name:");
			req.setCustomerName(sc.nextLine());
			System.out.println("Enter Pickup Address");
			req.setAddress(sc.nextLine());
			System.out.println("Enter Phone Number");
			req.setPhone(sc.nextLine());
			System.out.println("Enter Type of Cake");
			req.setTypeOfCake(sc.nextLine());
			req.setDateOfRequest(LocalDate.now());
			
			try {
				boolean result=cakeOrderService.validateRequest(req);
				if(result){
					int ret=cakeOrderService.makeRequest(req);
					System.out.println("Your order with id "+ret+" placed successfully");
				}
			} 
			catch (CakeOrderException e) {
				// TODO Auto-generated catch block
				System.out.println();
				System.err.println("An Error Occured "+e.getMessage());
				System.out.println();
			}
			
		}
		
		
		private void displayOrderDetails(){
			System.out.println("Enter Request id");
			int id=Integer.parseInt(sc.nextLine());
			try {
				CakeRequest req=cakeOrderService.getOrderDetailsById(id);
				System.out.println("Customer Name: "+req.getCustomerName());
				System.out.println("Order Id : "+req.getOrderId());
				System.out.println("Address :"+req.getAddress());
				System.out.println("Price:");
			} catch (CakeOrderException e) {
				// TODO Auto-generated catch block
				System.out.println();
				System.err.println("An Error Occured "+e.getMessage());
				System.out.println();
			}
		}
}
