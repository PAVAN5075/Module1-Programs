package com.cg.cakeorder.dao;

import java.util.HashMap;
import java.util.Random;
import com.cg.cakeorder.bean.CakeRequest;
import com.cg.cakeorder.db.CakeOrderDb;
import com.cg.cakeorder.exception.CakeOrderException;

public class CakeOrderDao implements ICakeOrderDao {
	static HashMap<Integer, CakeRequest> cakeorderMap=CakeOrderDb.getRequestDb();
	Random rand=new Random();
	@Override
	public int makeRequest(CakeRequest request) throws CakeOrderException {
		// TODO Auto-generated method stub
		int id =rand.nextInt(1000);
		request.setOrderId(id);
		cakeorderMap.put(request.getOrderId(), request);
		return request.getOrderId();
	}
	@Override
	public CakeRequest getOrderDetailsById(int id) throws CakeOrderException {
		// TODO Auto-generated method stub
		CakeRequest req=cakeorderMap.get(id);
		if(req==null){
			throw new CakeOrderException("Request with id "+id+" does not exist");
		}
		return req;
	}
	
}
