package com.cg.cakeorder.dao;

import com.cg.cakeorder.bean.CakeRequest;
import com.cg.cakeorder.exception.CakeOrderException;

public interface ICakeOrderDao {
	int makeRequest(CakeRequest request) throws CakeOrderException;
	CakeRequest getOrderDetailsById(int id) throws CakeOrderException;
}
