package com.cg.cakeorder.db;

import java.util.HashMap;

import com.cg.cakeorder.bean.CakeRequest;


public class CakeOrderDb {
	public static HashMap<Integer,CakeRequest> requestDb=new HashMap<Integer, CakeRequest>();

	public static HashMap<Integer, CakeRequest> getRequestDb() {
		return requestDb;
	}
}
