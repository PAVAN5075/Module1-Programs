package com.cg.cakeorder.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.cakeorder.bean.CakeRequest;
import com.cg.cakeorder.dao.CakeOrderDao;
import com.cg.cakeorder.dao.ICakeOrderDao;
import com.cg.cakeorder.exception.CakeOrderException;

public class CakeOrderService implements ICakeOrderService{
	ICakeOrderDao cakeOrderDao=new CakeOrderDao();

	@Override
	public int makeRequest(CakeRequest request) throws CakeOrderException {
		// TODO Auto-generated method stub
		FileInputStream fis=null;
		try {
			fis=new FileInputStream("cakeprice.properties");
			Properties p=new Properties();
			p.load(fis);
			int price=500+(Integer.parseInt(p.getProperty(request.getTypeOfCake())));
			//System.out.println(price);
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			throw new CakeOrderException(e.getMessage());
		}
		catch(IOException e){
			throw new CakeOrderException(e.getMessage());
		}
		finally{
			try {
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new CakeOrderException(e.getMessage());
			}
		}
		return cakeOrderDao.makeRequest(request);
	}

	@Override
	public boolean validateRequest(CakeRequest request) throws CakeOrderException {
		
		if(validatePhone(request.getPhone())){
			return true;
		}
		
		return false;
	}
	
	private boolean validatePhone(String phone) throws CakeOrderException{
		
		if(!phone.matches("\\d{10}")){
			throw new CakeOrderException("Phone Number must be of 10 digits");
		}
		return true;
	}

	@Override
	public CakeRequest getOrderDetailsById(int id) throws CakeOrderException {
		// TODO Auto-generated method stub
		return cakeOrderDao.getOrderDetailsById(id);
	}
	
	
}
