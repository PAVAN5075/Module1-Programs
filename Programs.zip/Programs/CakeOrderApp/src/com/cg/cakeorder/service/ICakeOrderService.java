package com.cg.cakeorder.service;

import com.cg.cakeorder.bean.CakeRequest;
import com.cg.cakeorder.exception.CakeOrderException;

public interface ICakeOrderService {
	int makeRequest(CakeRequest request) throws CakeOrderException;
	
	boolean validateRequest(CakeRequest request) throws CakeOrderException;
	CakeRequest getOrderDetailsById(int id) throws CakeOrderException;
}
