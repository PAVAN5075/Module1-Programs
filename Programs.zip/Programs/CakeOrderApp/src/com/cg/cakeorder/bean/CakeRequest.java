package com.cg.cakeorder.bean;

import java.time.LocalDate;

public class CakeRequest {
	private int orderId;
	private String customerName;
	private String address;
	private String phone;
	private String typeOfCake;
	private int price;
	private LocalDate dateOfRequest;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTypeOfCake() {
		return typeOfCake;
	}
	public void setTypeOfCake(String typeOfCake) {
		this.typeOfCake = typeOfCake;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDate getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(LocalDate dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	
	
}
