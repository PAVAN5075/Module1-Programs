package FileIO;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread t1=new Thread(new Timer());
		t1.start();
		
		
	}

}
