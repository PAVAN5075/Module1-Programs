package FileIO;
public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		while(true)
		{
			Factorial p=new Factorial();
			Thread t1=new Thread(new Runnable(){
				@Override
				public void run() {
					// TODO Auto-generated method stub
				
				p.number();
				}
			}
		);
			
			Thread t2=new Thread(new Runnable()
			{	
				@Override
				public void run() 
				{
					// TODO Auto-generated method stub
				p.fact();
				}		
			}	
			
					);	
				
				t1.start();
				try {
					t1.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				t2.start();
				try {
					t2.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
						
	}
}
		