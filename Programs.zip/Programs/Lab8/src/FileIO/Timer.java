package FileIO;

public class Timer implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(int i=0;i<=10;i++){
			System.out.println(i+" ");
			try{
				Thread.sleep(10000);
				
			if(i==10)
			{
				i=1;
				System.out.println();
				System.out.println(i+" ");
				Thread.sleep(1000);
				
			}
			}catch (InterruptedException e){
				e.printStackTrace();
				
			}
		
	}

	}
}

