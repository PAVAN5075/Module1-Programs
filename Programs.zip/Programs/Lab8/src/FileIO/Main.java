package FileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		FileInputStream fis= new FileInputStream("d:/file/abc.txt");
		Thread t1=new Thread(new copyData(fis));
		
	}

}
