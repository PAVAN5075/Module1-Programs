package FileIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class copyData implements Runnable {
	

	FileInputStream fis;
	copyData(FileInputStream fis)
	{
		this.fis=fis;
	}	

	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream("d:/file/target.txt");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					 
		byte[] Buffer = null;
		try {
			Buffer = new byte[fis.available()];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fis.read(Buffer);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0;i<Buffer.length;i++)
		{
			try {
				fos.write(Buffer[i]);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if((i%10)==0)
			{
				System.out.println("10 charactersare copied");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		System.out.println("\n"+"file copied successfully");
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

		
		
		
	






