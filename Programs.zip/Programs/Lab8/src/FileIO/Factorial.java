package FileIO;

public class Factorial 
{

	double n=(int)(Math.random()*10);
	public void number()
	{
		System.out.println("Number:"+n);
		
	}
	public void fact()
	{
		int res=1;
		for(int i=2; i<=n;i++){
			res=res*i;
			
		}
		System.out.println("Factorial of "+n+ ":"+res);
		
	}
}
