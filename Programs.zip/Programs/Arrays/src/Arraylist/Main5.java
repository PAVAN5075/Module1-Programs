package Arraylist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import arr.Student;

public class Main5 {

	public Main5() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list2=new ArrayList<Integer>();
		list2.add(1);
		list2.add(12);
		list2.add(123);
		list2.add(1234);
		
		List list=new ArrayList();
		list.add(1);
		list.add("KPS");
		list.add('M');
		list.add(12.34);
		list.add(true);
		list.add(new Student());
		list.addAll(list2);
		
		Collections.sort(list2);
		System.out.println(list2);
		
		System.out.println("First element="+list.get(1));
		
		int l=list.size();
		
		Iterator<Integer> iter= list2.iterator();
		while(iter.hasNext()){
			int val=iter.next();
			if(val>1000){
				iter.remove();
			}
		}
		
		System.out.println("After remove"+list2);
		
		for(int i=0;i<l;i++){
			Object ele=list.get(i);
			if(ele instanceof Float){
				Float iv=Float.valueOf(ele.toString());
				System.out.println(ele);
			}
		}
		boolean b=list.contains(new Character('M'));
		boolean b1=list.containsAll(list2);
		System.out.println(b1);
		list.removeAll(list2);
		System.out.println(list);
		System.out.println(b);
		System.out.println(list);
		
		
	}
}
