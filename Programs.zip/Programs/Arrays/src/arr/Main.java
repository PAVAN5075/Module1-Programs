package arr;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
int arry[]=new int[3];
int [][]brry=new int[3][3];
int crry[][][]=new int[3][3][3];
System.out.println(arry.length);

String d[]=new String[]{"K P S"};
for(String i:d){
	System.out.println(i);
}

System.out.println(arry);
System.out.println(brry);
System.out.println(crry);

for (int i = 0; i < arry.length; i++) {
	arry[i]=sc.nextInt();
}
//for each loop ----> specially designed for arrys & collections
for(int i:arry){
	System.out.println(i);
}
	}

}
