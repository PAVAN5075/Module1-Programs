package arr;

public class Main2 {

	public Main2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student srr[]=new Student[3];
		srr[0]=new Student("KPS",1);
		srr[1]=new Student("PSK",2);
		srr[2]=new Student("PKS",3);
		for (int i = 0; i < srr.length; i++) {
			System.out.println(srr[i]);
		}
	}
}
