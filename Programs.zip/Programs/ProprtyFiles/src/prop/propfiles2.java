package prop;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Set;

public class propfiles2 {

	public static void main(String[] args) throws IOException {
		
		Properties p= new Properties();
		
		p.setProperty("1000", "Manu");
		p.setProperty("1001", "Anu");
		p.setProperty("1002", "Anil");
		p.setProperty("1003", "Sumil");
		
		/*p.remove("1001");
		
		FileOutputStream out =new FileOutputStream("name.txt");
		p.store(out, "Details of names");
		out.close();
		System.out.println("Done!");*/
		
		/*System.out.println(p.contains("Manu"));
		System.out.println(p.containsKey("1002"));*/
		
		/*Enumeration<Object> e= p.elements();
		while(e.hasMoreElements()){
			System.out.println(e.nextElement());}*/
		
		/*Enumeration<Object> e= p.keys();
		while(e.hasMoreElements()){
			System.out.println(e.nextElement());}*/
		
		/*Enumeration e=p.propertyNames();
		while(e.hasMoreElements()){
			System.out.println(e.nextElement());}*/
		
		}

	}

