package prop;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Properties;

public class propfiles {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream in=new FileInputStream("data.properties");
		Properties props=new Properties();
		
		props.load(in);
		System.out.println(props.getProperty("name"));
		System.out.println(props.getProperty("Company"));
		System.out.println(props.getProperty("City"));
		System.out.println(props.getProperty("State"));
		System.out.println(props.getProperty("Fruits"));
		
		
		
		/*FileOutputStream out=new FileOutputStream("backup.properties");
		props.store(out, "Duplicate file for data.properties");*/
		
		//FileOutputStream out =new FileOutputStream("list.txt");
		FileWriter out =new FileWriter("list1.txt");
		PrintWriter ps=new PrintWriter(out);
		props.list(ps);
		ps.close();
		out.close();
		
	}

}
