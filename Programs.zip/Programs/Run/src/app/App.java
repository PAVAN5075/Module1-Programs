package app;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UtilClass u=new UtilClass();
		boolean result=u.areEqual(10,10);
		System.out.println(result);;
	}

}
