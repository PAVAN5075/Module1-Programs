package app;

import java.util.List;

public class DAOImpl {
	private List listEmp;
	public DAOImpl() {
		// TODO Auto-generated constructor stub
		public void insert(Emp e){
		listEmp.add(e);
		}
		
		public void delete(Emp e){
			listEmp.remove(e);
			}
	}
	@Override
	public String toString() {
		return "DAOImpl [listEmp=" + listEmp + "]";
	}
	

}
