package app;

public class C extends B {
	public C(){
		System.out.println("C");
	}

}
