package app;

public class UtilClass {
	public boolean areEqual(Object num1, Object num2){
			return num1.equals(num2);
	}
}
