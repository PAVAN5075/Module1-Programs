/**
 * 
 */
package app;

/**
 * @author pkomarra
 *
 */
public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20;
		int c=a+b;
		System.out.println("The addition of "+a+" and "+b+" is " +c+".");
		c=a-b;
		System.out.println("The substraction of "+a+" and "+b+" is " +c+".");
		c=a*b;
		System.out.println("The multiplication of "+a+" and "+b+" is " +c+".");
		float d=(float)a/b;
		System.out.println("The quotient of "+a+" divided by "+b+" is " +d+".");
		d=(float)a%b;
		System.out.println("The remainder of "+a+" divided by "+b+" is " +d+".");
		int result=a>>1;
		System.out.println("The right shift of "+a+" by 1 bit is "+result+".");
		result=a<<2;
		System.out.println("The left shift of "+a+" by 2 bits is "+result+".");
		boolean status=a<b;
		if(status){
			System.out.println(+b+" is greaterthan "+a);
		}
		else{
			System.out.println(+a+" is greaterthan "+b);
		}
	}
}