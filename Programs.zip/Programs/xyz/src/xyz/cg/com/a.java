package xyz.cg.com;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class a {
 private String Day;

private List<String> game;

public List<String> getGame() {
	return game;
}

public void setGame(List<String> game) {
	this.game = game;
}

public String getDay() {
	return Day;
}

public void setDay(String day) {
	Day = day;
}
}