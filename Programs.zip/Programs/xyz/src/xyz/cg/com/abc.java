 package xyz.cg.com;

 import java.util.HashMap;

 public class abc {
   public static  void main(String[] args) {
     HashMap<String, String> hMap = new HashMap<String, String>();

     hMap.put("1", "One");
     hMap.put("2", "Two");
     hMap.put("3", "Three");

     //if((hMap.containsValue("Two"))){
    	 System.out.println( hMap.get("Two"));
    
  // }
    
   }
 }
  
 