package Lab3Assignments;

	import java.time.LocalDate;
	import java.time.Month;
	import java.time.Period;

	public class Duration {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			LocalDate start=LocalDate.of(2018, Month.MAY, 17);
			LocalDate end=LocalDate.of(1997, Month.MAY, 17);
			System.out.println(Period.between(start, end));
			
		}
	}
