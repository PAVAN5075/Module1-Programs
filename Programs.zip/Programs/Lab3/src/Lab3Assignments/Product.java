package Lab3Assignments;

import java.time.LocalDate;

public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate buy=LocalDate.now();
		System.out.println(buy.plusDays(12));
		System.out.println(buy.plusMonths(3));
		System.out.println(buy.plusYears(2));

	}

}
