package Lab3Assignments;

import java.util.Scanner;

public class Jobseeker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String str=sc.nextLine();
		int l=str.length(),k=0;
		sc.close();
		if(str.endsWith("_job") && l-4>8)
		{
			k=1;
		}
		else
			k=2;
		if(k==1)
		{
			System.out.println("validation is passed");
		}
		else
			System.out.println("validation is failed");
	}

}