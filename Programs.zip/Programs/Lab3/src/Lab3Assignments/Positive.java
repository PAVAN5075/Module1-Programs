package Lab3Assignments;

import java.util.Scanner;

public class Positive {
	String str;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		System.out.println(str);
		 int a=str.length(),b=0;
		for(int i=0;i<a-1;i++)
		{
				
				if((str.charAt(i))-(str.charAt(i+1))>0)
				{
					b=1;
					break;
				}
				else{
					b=2;
				}
					
			}
		if(b==1)
			System.out.println("Not a Positive string");
		else
			System.out.println("Positive string");
	}
	}
