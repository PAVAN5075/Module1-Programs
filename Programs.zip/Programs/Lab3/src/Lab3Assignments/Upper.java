package Lab3Assignments;

import java.util.Scanner;

public class Upper {

	public static String[] array;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		sc.close();
		String s1="";
		int l=str.length();
		for (int i = 0; i < l; i++) {
			if(i%2==0){
				s1=s1+str.charAt(i);
			}
			if(i%2!=0){
				char c=str.charAt(i);
				Character c1=new Character(c);
				String s=c1.toString();
				String u=s.toUpperCase();
				s1=s1+u;
			}
		}
System.out.println(s1);
	}

}
