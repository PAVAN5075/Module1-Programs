package Lab3Assignments;

import java.util.Scanner;

public class concat {
	String str;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String str1=str+str;
		System.out.println(str1);
         char[] array=str.toCharArray();
         char[] array1=str.toCharArray();
        int a=str.length();
        sc.close();
        System.out.println(a);
        for(int i=0;i<a;i++)
        {
        	if(i%2==0)
        	{
        		 array[i]='#';
        	}
        	else
        		continue;
        }
        int b=0;
        for(int i=0;i<a;i++)
        {
        	System.out.println(array[i]);
        }
        for(int i=0;i<a;i++)
        {
        	for(int j=i+1;j<a;j++)
        	{
        		
        		if(array[i]==array[j])
        		{
        			array[i]='\u0000';
        			array[i]=array[i+1];
        			//i++;
        			//b++;
        		}
        		else
        			continue;
        	}
        }
        for(int i=0;i<a;i++)
        {
        	System.out.println(array[i]);
        }

	}

}
