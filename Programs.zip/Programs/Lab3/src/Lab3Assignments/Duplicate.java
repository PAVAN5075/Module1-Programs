package Lab3Assignments;

import java.util.Scanner;

public class Duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		sc.close();
		StringBuffer st=new StringBuffer(str);
		//System.out.println(str);
		for (int i = 0; i < st.length()-1; i++) {
			for (int j = i+1; j <st.length(); j++) {
				if(st.charAt(i) == st.charAt(j))
					st.deleteCharAt(j);
					//System.out.println(st.charAt(j));
			}
		}
		System.out.println("After removing duplicates from the given string: "+st);
	}

}
