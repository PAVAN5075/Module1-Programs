package Lab3Assignments;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class zone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ZonedDateTime currenttime=ZonedDateTime.now();
		ZonedDateTime America=ZonedDateTime.now(ZoneId.of("America/New_York"));
		ZonedDateTime Australia=ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
		System.out.println("India:"+currenttime);
		System.out.println("America:"+America);
		System.out.println("Australia:"+Australia);
	}

}
