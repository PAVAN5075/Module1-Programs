package Lab3Assignments;

import java.util.Scanner;

public class SortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of names");
		int n=sc.nextInt();
		String s[]=new String[n];
		String temp;
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter the names");
		for (int i = 0; i < n; i++) {
			s[i]=sc1.nextLine();
		}
		System.out.println("After sorting");
		for (int i = 0; i < n; i++) {
			for (int j = i+1; j < n; j++) {
				if(s[i].compareTo(s[j])>0){
					temp=s[i];
					s[i]=s[j];
					s[j]=temp;
				}
			}
			System.out.println(s[i]);
		}
		
			if(n%2==0){
				for (int i = 0; i < n/2; i++) {
			s[i]=s[i].toUpperCase();
			System.out.println(s[i]);
		}
				for(int i=n/2;i<n;i++){
					s[i]=s[i].toLowerCase();
					System.out.println(s[i]);
				}
			}
				if(n%2!=0){
					for (int i = 0; i < n/2+1; i++) {
				s[i]=s[i].toUpperCase();
				System.out.println(s[i]);
			}
					for(int i=n/2+1;i<n;i++){
						s[i]=s[i].toLowerCase();
						System.out.println(s[i]);
					}
	}


}
}
