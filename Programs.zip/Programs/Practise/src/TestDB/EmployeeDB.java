package TestDB;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import Test.Employee;

public class EmployeeDB {
	private static HashMap<Integer, Employee> empDb=new HashMap<Integer, Employee>();
	
	public static HashMap<Integer,Employee>getDb(){
		return empDb;
		
	}
	static {
		empDb.put(1001,new Employee(1001,"Mark","Male",23,"Programmer","9848121212",LocalDate.of(2016, Month.APRIL, 21),56000));
		empDb.put(1002,new Employee(1002,"Sara","Female",32,"Analyst","9440121212",LocalDate.of(2012, Month.AUGUST, 10),78000));
		empDb.put(1003,new Employee(1003,"John","Male",43,"Manager","9949121212",LocalDate.of(1999, Month.FEBRUARY, 12),98000));
		
	}
}
