package TestService;

import java.util.Collection;
import java.util.List;

import Test.Employee;
import Test.EmployeeException;

public interface IEmployeeService {

		Collection<Employee> getAllEmployee() throws EmployeeException;
		Employee getEmployeeById(int id) throws EmployeeException;
		boolean validateEmployee(Employee emp) throws EmployeeException;
		int addEmployee (Employee emp) throws EmployeeException;
		int deleteEmployee(int id) throws EmployeeException;
		List<Employee> getEmployeeByDesignation(String designation) throws EmployeeException;
		Employee findSeniorMostEmployee() throws EmployeeException;
		int updateEmployee(Employee emp) throws EmployeeException;
}
