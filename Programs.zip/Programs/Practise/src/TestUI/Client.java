package TestUI;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import Test.Employee;
import Test.EmployeeException;
import TestService.EmployeeService;
import TestService.IEmployeeService;

public class Client {
	Scanner scan=new Scanner(System.in);
	IEmployeeService service=new EmployeeService();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client c=new Client();
		String option="";
		while(true){
			System.out.println("1. Display All Employees");
			System.out.println("2. Add an Employee");
			System.out.println("3. Delete an Employee");
			System.out.println("4. Update an Employee");
			System.out.println("5. Display Employee by id");
			System.out.println("6. Display Employees by Designation");
			System.out.println("7. Display the Senior Most Employee");
			System.out.println("8. Exit");
			System.out.println("Enter your choice");
			option=c.scan.nextLine();
			switch (option) {
			case "1":
				c.displayAllEmployee();
				
				break;
			case "2":
				c.addEmployee();
				break;
			case "3":
				c.deleteEmployee();
				break;
			case "4":
				c.updateEmployee();
				break;
			case "5":
				c.displayEmployeeById();
				break;
			case "6":
				c.displayEmpByDesig();
				break;
			case "7":
				c.findSenior();
				break;
			case "8":
				System.exit(0);
				break;
			default:
				System.out.println("Please Select Option from 1 to 8");
				break;
			}
		}

	}



private void displayAllEmployee(){
	try {
		Collection<Employee> employees=service.getAllEmployee();
		employees.forEach(System.out::println);
	} catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}


private void displayEmployeeById(){
	System.out.println("Enter thye Employee Id");
	int id=Integer.parseInt(scan.nextLine());
	try {
		Employee emp=service.getEmployeeById(id);
		System.out.println(emp);
	} 
	catch (EmployeeException e) {
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}


public void addEmployee(){
	Employee emp=new Employee();
	System.out.println("Enter Employee Id:");
	emp.setId(Integer.parseInt(scan.nextLine()));
	System.out.println("Enter Name:");
	emp.setName(scan.nextLine());
	System.out.println("Enter Gender:");
	emp.setGender(scan.nextLine());
	System.out.println("Enter Age");
	emp.setAge(Integer.parseInt(scan.nextLine()));
	System.out.println("Enter Designation:");
	emp.setDesignation(scan.nextLine());
	System.out.println("Enter Mobile Number:" );
	emp.setMobile(scan.nextLine());
	emp.setDOJ(LocalDate.now());
	System.out.println("Enter Salary:");
	emp.setSalary(Double.parseDouble(scan.nextLine()));
	try {
		boolean result=service.validateEmployee(emp);
		if(result){
			int ret=service.addEmployee(emp);
			System.out.println("Employee with id "+ret+" has been added to the Data Base Successfully");
		}
	} 
	catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}


private void deleteEmployee(){
	System.out.println("Enter Employee id");
	int id=Integer.parseInt(scan.nextLine());
	try {
		int result=service.deleteEmployee(id);
		System.out.println("Employee with id "+id+" is deleted successfully");
	} catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}

private void displayEmpByDesig(){
	System.out.println("Enter Designation");
	String desig=scan.nextLine();
	try {
		List<Employee> employees = service.getEmployeeByDesignation(desig);
		employees.forEach(System.out::println);
		
	} 
	catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}


private void findSenior(){
	try {
		Employee emp=service.findSeniorMostEmployee();
		System.out.println(emp);
	} catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}

private void updateEmployee(){
	System.out.println("Enter Employee id");
	int id=Integer.parseInt(scan.nextLine());
	try {
		Employee emp=service.getEmployeeById(id);
		System.out.println("Employee Current Details:");
		System.out.println(emp);
		Employee emp1= new Employee();
		System.out.println("Enter Name:");
		emp1.setName(scan.nextLine());
		System.out.println("Enter Gender:");
		emp1.setGender(scan.nextLine());
		System.out.println("Enter Age");
		emp1.setAge(Integer.parseInt(scan.nextLine()));
		System.out.println("Enter Designation:");
		emp1.setDesignation(scan.nextLine());
		System.out.println("Enter Mobile Number:" );
		emp1.setMobile(scan.nextLine());
		System.out.println("Enter Salary:");
		emp1.setSalary(Double.parseDouble(scan.nextLine()));
		emp1.setId(emp.getId());
		emp1.setDOJ(emp.getDOJ());
		boolean b=service.validateEmployee(emp1);
		if(b){
			int ret=service.updateEmployee(emp1);
			System.out.println("Employee details with id "+ret+" updated successfully");
		}
		
	} 
	catch (EmployeeException e) {
		// TODO Auto-generated catch block
		System.out.println("");
		System.err.println("An Error Occured: "+e.getMessage());
		System.out.println();
	}
}

}
