package Test;

import java.time.LocalDate;

public class Employee {
	
	private int id;
	private String name;
	private String gender;
	private int age;
	private String designation;
	private String mobile;
	private LocalDate DOJ;
	private double Salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public LocalDate getDOJ() {
		return DOJ;
	}
	public void setDOJ(LocalDate dOJ) {
		DOJ = dOJ;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", gender=" + gender
				+ ", age=" + age + ", designation=" + designation + ", mobile="
				+ mobile + ", DOJ=" + DOJ + ", Salary=" + Salary + "]";
	}
	public Employee(int id, String name, String gender, int age,
			String designation, String mobile, LocalDate dOJ, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.designation = designation;
		this.mobile = mobile;
		DOJ = dOJ;
		Salary = salary;
	}

	public Employee(){
		
	}
	
	
	
}
