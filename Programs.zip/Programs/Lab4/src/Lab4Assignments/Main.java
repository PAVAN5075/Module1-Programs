package Lab4Assignments;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Savings s=new Savings();
		Current c=new Current();
		s.withdraw(2000);
		c.withdraw(4000);

	}

}

