package Lab4Assignments;

public class Account {
		// TODO Auto-generated constructor stub
		int amount=3000;
		public void withdraw(int b){
			amount=amount-b;
			System.out.println(amount);
		}

}
