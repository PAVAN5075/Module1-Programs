package Lab4Assignments;

public class Current extends Account{
	int overdraft=500;
	boolean k;
	@Override
	public void withdraw(int b) {
		// TODO Auto-generated method stub
		if(b<overdraft){
			k=true;
		}
		else
			k=false;
		System.out.println(k);
	}
	

}
