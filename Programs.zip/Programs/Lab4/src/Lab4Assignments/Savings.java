package Lab4Assignments;

public class Savings extends Account {
	int balance=500;

	@Override
	public void withdraw(int b) {
		// TODO Auto-generated method stub
		super.withdraw(b);
	
	if(b>balance)
	{
		System.out.println("withdraw is allowed");
	}
	else
	{
	System.out.println("withdraw is not allowed");	
	}
	}
}
