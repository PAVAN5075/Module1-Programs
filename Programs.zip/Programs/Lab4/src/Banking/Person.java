package Banking;

public class Person extends Account {
	String name;
	float age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	/*name=p1.setName("Smith");
	age=p1.setAge(25.5f);
	name=p2.setName("Kathy");
	age=p2.setAge(21.5f);*/
}

