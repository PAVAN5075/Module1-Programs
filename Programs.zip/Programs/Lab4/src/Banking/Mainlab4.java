package Banking;

public class Mainlab4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1=new Person();
		Person p2=new Person();
		Account a=new Account();
		Account b=new Account();
		a.setAccNum(1233548*Math.random());
		a.setBal(2000);
		double a1=a.getBal();
		p1.setName("Smith");
		p1.setAge(25.5f);
		System.out.println("Name: "+p1.getName());
		System.out.println("Account Number: "+a.getAccNum());
		System.out.println("Age: "+p1.getAge());
		System.out.println("exixting balence is: "+a1);
		a.deposit(2000);
		
		System.out.println("");
		
		p2.setName("Kathy");
		p2.setAge(21.5f);
		b.setAccNum(1233548*Math.random());
		b.setBal(3000);
		double b1=b.getBal();
		System.out.println("Name: "+p2.getName());
		System.out.println("Account Number: "+b.getAccNum());
		System.out.println("Age: "+p2.getAge());
		System.out.println("exixting balence is: "+b1);
		b.withdraw(2000);
		
	}

}
