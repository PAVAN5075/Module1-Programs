package Banking;

public class Account {
	int accNum;
	double bal,dep,wdr;

	public double getAccNum() {
		return accNum;
	}
	public void setAccNum(double accNum) {
		this.accNum = (int) accNum;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public double getDep() {
		return dep;
	}
	public void setDep(double dep) {
		this.dep = dep;
	}
	public double getWdr() {
		return wdr;
	}
	public void setWdr(double wdr) {
		this.wdr = wdr;
	}
		
	public void deposit(double dep) {
		// TODO Auto-generated method stub
		this.bal=this.getBal()+dep;
		System.out.println("updated balence is: "+this.bal);
	}

	public void withdraw(double wdr) {
		// TODO Auto-generated method stub
		this.bal=this.getBal()-wdr;
		System.out.println("updated balence is: "+this.bal);
	}
}
