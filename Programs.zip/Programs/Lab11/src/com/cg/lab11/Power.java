package com.cg.lab11;
import java.util.Scanner;

interface powerMethod{
	double power(int n1,int n2);
}
public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		powerMethod p = (x,y)->Math.pow(x, y);
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a value");
		int a = scan.nextInt();
		System.out.println("Enter exponent value");
		int b = scan.nextInt();
		double result = p.power(a,b);
		System.out.println(a + "power" + b + "is" + result);
	}

}
