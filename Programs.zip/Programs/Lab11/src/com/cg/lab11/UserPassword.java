package com.cg.lab11;

import java.util.Scanner;

public class UserPassword {

	interface validateFunction{
	boolean authenticate(String user,String pwd);
		
	}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			validateFunction m = (x,y)->{
				boolean b1 = false;
				if(x.matches("[A-Z][]a-zA-Z]{2,10}")){
					if(y.matches("[A-Z][a-z0-9]{2,10}")){
						b1 = true;
					}
				}
				else{
					b1 = false;
				}
				return b1;
	
			};
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter username: ");
			String un = sc.nextLine();
			System.out.println("Enter username: ");
			String pwd = sc.nextLine();
			boolean b= m.authenticate(un, pwd);
			System.out.println(b);
		}
	}


