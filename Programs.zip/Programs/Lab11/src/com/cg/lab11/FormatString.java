package com.cg.lab11;

import java.util.Scanner;

	interface format{
		String formatting(String s);
	}
	public class FormatString {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			format m = (x)->{
				String s[] = x.split("");
				StringBuilder sb = new StringBuilder();
				for(int i = 0;i<s.length;i++){
					sb.append(s[i]);
					sb.append(" ");
				}
				String s1 = sb.toString();
				return s1;
			};
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter a string to format:  ");
			String str = scan.nextLine();
			String s2 = m.formatting(str);
			System.out.println("String After formatting "+"\n"+s2);
	}
}
