package com.cg.lab11;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,Employee> map=new HashMap<Integer,Employee>();
		map.put(10, new Employee(10,"Anil",5000));
		map.put(11, new Employee(11,"Sunil",8000));
		map.put(12, new Employee(12,"Kamal",10000));
		Optional<Double> sum=map.values().stream().map(x->x.getSalary()).reduce((a,b)->a+b);
		System.out.println(sum.get());

	}

}
