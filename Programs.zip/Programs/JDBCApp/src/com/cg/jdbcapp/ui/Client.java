package com.cg.jdbcapp.ui;

import java.util.Scanner;

import com.cg.jdbcapp.dto.Employee;

public class Client {
	Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String option="";
		while(true){
			
			System.out.println("1. Add an Employee");
			System.out.println("2. List All Employees");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			switch (option) {
			case "1":
				
				
				break;
			case "2":
				
				break;
			case "3":
				System.exit(0);
				break;
			default:
				System.out.println("Please Select Option from 1 to 8");
				break;
			}
		}
		
	}

	private void addEmployee(){
		Employee emp=new Employee();
		System.out.println("Enter Employee Id:");
		
	}
	
	
}
