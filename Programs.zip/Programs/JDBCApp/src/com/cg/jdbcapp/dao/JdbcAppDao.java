package com.cg.jdbcapp.dao;

import com.cg.jdbcapp.dto.Employee;
import com.cg.jdbcapp.exception.JDBCAppException;

public class JdbcAppDao {
	
	public int addEmployee(Employee emp) throws JDBCAppException();
	
}
