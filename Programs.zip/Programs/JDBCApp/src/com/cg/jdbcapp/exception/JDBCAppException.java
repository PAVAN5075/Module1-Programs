package com.cg.jdbcapp.exception;

public class JDBCAppException extends Exception{
	
	public JDBCAppException{
		
	}
	
}
