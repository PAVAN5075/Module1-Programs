package com.cg.cakeapp.dao;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.exception.CakeException;

public interface ICakeDao {
	int placeOrder(Customer c,CakeOrder o) throws CakeException;
	CakeOrder getOrderDetails(int orderId) throws CakeException;
}

