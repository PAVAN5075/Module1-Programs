package com.cg.cakeapp.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.exception.CakeException;

public class CakeDao implements ICakeDao{

	private static Map<Integer,CakeOrder> cakeMap=
			new HashMap<Integer,CakeOrder>();
	private static Map<Integer,Customer> customerMap=
			new HashMap<Integer,Customer>();
	
	Random rand=new Random();
	@Override
	public int placeOrder(Customer c, CakeOrder o) throws CakeException {
		try {
		int custId=rand.nextInt(1000);
		int orderId=rand.nextInt(1000);
		c.setCustomerId(custId);
		o.setCustomerId(custId);
		o.setOrderId(orderId);
		cakeMap.put(o.getOrderId(), o);
		customerMap.put(c.getCustomerId(), c);
		return o.getOrderId();
		}
		catch(Exception e) {
			throw new CakeException(e.getMessage());
		}
	}
	@Override
	public CakeOrder getOrderDetails(int orderId) throws CakeException {
		if(!cakeMap.containsKey(orderId)) {
			throw new CakeException("Invalid Order Id");
		}
		CakeOrder order=cakeMap.get(orderId);
		return order;
	}

}

