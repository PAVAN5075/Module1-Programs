package com.cg.cakeapp.exception;

public class CakeException extends Exception{
	public CakeException() {
		super();
	}
	public CakeException(String msg) {
		super(msg);
	}
}

