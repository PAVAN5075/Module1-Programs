package com.cg.cakeapp.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.exception.CakeException;
import com.cg.cakeapp.service.CakeService;
import com.cg.cakeapp.service.ICakeService;

public class Client {
	Scanner sc=new Scanner(System.in);
	ICakeService service=new CakeService();
	public static void main(String[] args) {
		Client c=new Client();
		String option="";
		while(true) {
			System.out.println("1. Place Order");
			System.out.println("2. Display Order");
			System.out.println("3. Exit");
			System.out.println("Enter Your choice");
			option=c.sc.nextLine();
			
			switch(option) {
			case "1":
				c.acceptOrder();
				break;
			case "2":
				c.displayOrder();
				break;
			case "3":
				c.sc.close();
				System.exit(0);
			default:
				System.out.println("Enter option between 1 and 3");
				break;
			}
			
		}

	}
	private void acceptOrder() {
		Customer c=new Customer();
		CakeOrder o=new CakeOrder();
		System.out.print("Enter Customer Name");
		c.setCustomerName(sc.nextLine());
		System.out.print("Enter Customer Address");
		c.setAddress(sc.nextLine());
		System.out.print("Enter Phone");
		c.setPhone(sc.nextLine());
		System.out.print("Enter Cake type");
		String type=sc.nextLine();
		try {
			double price=service.getPrice(type);
			o.setTotalPrice(price);
			System.out.println("Price "+price);
			System.out.println("Order Date "+LocalDate.now());
			int id=service.placeOrder(c, o);
			System.out.println("Cake Order Successfully Placed with Order Id "+id);
		} catch (CakeException e) {
			System.out.println();
			System.err.println(e.getMessage());
			System.out.println();
		}
		
	}
	private void displayOrder() {
		System.out.print("Enter Order id ");
		int id=Integer.parseInt(sc.nextLine());
		try {
			CakeOrder order=service.getOrderDetails(id);
			System.out.println("Order Id :"+order.getOrderId());
			System.out.println("Customer id :"+order.getCustomerId());
			System.out.println("Total Price :"+order.getTotalPrice());
		} catch (CakeException e) {
			System.out.println();
			System.err.println(e.getMessage());
			System.out.println();
		}
	}

}

