package com.cg.cakeapp.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.dao.CakeDao;
import com.cg.cakeapp.dao.ICakeDao;
import com.cg.cakeapp.exception.CakeException;

public class CakeService implements ICakeService{

	ICakeDao dao=new CakeDao();
	@Override
	public double getPrice(String type) throws CakeException {
		double totalPrice=0;
		FileInputStream fis=null;
		try {
			fis=new FileInputStream("cake.properties");
			Properties p=new Properties();
			p.load(fis);
			String value=p.getProperty(type);
			if(value!=null) {
				totalPrice=500+Double.parseDouble(value);
			}
			else {
				throw new CakeException("Invalid Cake Type");
			}
		} catch (FileNotFoundException e) {
			throw new CakeException(e.getMessage());
		} catch (IOException e) {
			throw new CakeException(e.getMessage());
		}
		finally {
			if(fis!=null) {
				try {
					fis.close();
				} catch (IOException e) {
					throw new CakeException(e.getMessage());
				}
			}
		}
		return totalPrice;
	}

	@Override
	public int placeOrder(Customer c, CakeOrder o) throws CakeException {
		// TODO Auto-generated method stub
		return dao.placeOrder(c, o);
	}

	@Override
	public CakeOrder getOrderDetails(int orderId) throws CakeException {
		// TODO Auto-generated method stub
		return dao.getOrderDetails(orderId);
	}

}

