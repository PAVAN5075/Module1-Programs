package com.cg.cakeapp.service;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.exception.CakeException;

public interface ICakeService {
	double getPrice(String type) throws CakeException;
	int placeOrder(Customer c,CakeOrder o) throws CakeException;
	CakeOrder getOrderDetails(int orderId) throws CakeException;
}
