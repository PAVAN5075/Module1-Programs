package com.cg.cakeapp.test;


import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.cakeapp.bean.CakeOrder;
import com.cg.cakeapp.bean.Customer;
import com.cg.cakeapp.dao.CakeDao;
import com.cg.cakeapp.dao.ICakeDao;
import com.cg.cakeapp.exception.CakeException;

public class CakeDaoTest {
	private ICakeDao dao;
	@BeforeClass
	public void init() {
		dao=new CakeDao();
	}
	@Test
	public void testPlaceOrder() throws CakeException {
		Customer customer=new Customer();
		CakeOrder cakeOrder=new CakeOrder();
		cakeOrder.setTotalPrice(500);
		//Cannot check the placeOrder orderid since it is a randomly generated number
		Assert.assertNotEquals(500.00,dao.placeOrder(customer, cakeOrder));
		
		
	}

	@Test
	public void testGetOrderDetails() throws CakeException {
		int orderId=100;
		assertNull(dao.getOrderDetails(orderId));
	}
	@Test(expected=CakeException.class)
	public void testException() throws CakeException {
		dao.getOrderDetails(100);
		
	}

}

