/**
 * 
 */
package login;

import java.util.Date;

/**
 * @author pkomarra
 *
 */
public class HelloWorld {

	/**
	 * Author : Pavan
	 * Date : 21-06-2018
	 * Description : Simple JAVA Program
	 */
	public static void main(String[] args) {
		Calc c=new Calc();
		Date d=new Date();
		c.print();
		System.out.println(d);
		Calc obj=new Calc();
		int y=obj.addition(12, 15);
System.out.println("The value of add is " +y);
		System.out.println("Hello World");
	}
}