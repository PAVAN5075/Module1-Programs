package login;

public class Calc {
	
	public void print(){
		for (int i = 0;i<10;i++)
		{
			int c=10;
			int d = c+i;
			//System.out.println(d);//
		}
	}
public int addition (int a, int b) {
	int c=a+b;
	return c;
}
}
