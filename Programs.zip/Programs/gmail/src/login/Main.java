package login;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start=System.currentTimeMillis();
		System.out.println(start);
		byte b=10;
		short s=20;
		int i=12;
		long l=12345678;
		float f=12.34f;
		double d=1234.5678;
		char gender='M';
		String name="123";
		boolean st=false;
		/* implicit 
		s=b;
		i=s;
		l=i;*/
		
		//explicit type casting
		i=(int)f;
		s=(short)i;
		b=(byte)s;
		
		int pp=Integer.parseInt(name);
		float ppp=Float.parseFloat(name);
		System.out.println(ppp);
		System.out.println(Integer.MAX_VALUE);
		
		String bin=Integer.toBinaryString(i);
		System.out.println(bin);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("En nm");
		String s1=sc.nextLine();
		System.out.println(s1);
		
		long end=System.currentTimeMillis();
		System.out.println(end);
		
		System.out.println("Time elapsed "+(end-start));
		
		LocalDate datenow=LocalDate.now();
		System.out.println(datenow);
		LocalTime timenow=LocalTime.now();
		System.out.println(timenow);
	}

}
