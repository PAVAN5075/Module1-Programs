package SurpriseTest;

public class Rocket {
	private void blastOff() { System.out.print("bang "); }
}
