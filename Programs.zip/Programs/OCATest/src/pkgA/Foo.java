package pkgA;

public class Foo {
int a = 5;
protected int b = 6;
public int c = 7;
}
