package sorting;

import java.util.ArrayList;
import java.util.List;

public class SortingArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> al = new ArrayList<String>();
		al.add("C");
		al.add("A");
		al.add("E");
		al.add("B");
		al.add("D");
		al.add("F");
	    al.sort(null);
	    
	    //System.out.println(al);
	    
	    for (String string : al) {
			System.out.println(string);
		}
	}

}
