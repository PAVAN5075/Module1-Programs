package sorting;

import java.util.Arrays;
import java.util.Scanner;

public class sort {

	public sort() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int a[]=new int[4];
		int b[]=new int[4];
		for (int i = 0; i < a.length; i++) {
			System.out.println("Enter the Element "+i);
			a[i]=sc.nextInt();
		}
		for (int i = 0; i < a.length; i++) {
			int y,n=0;
			while(a[i]!=0){
				y=a[i]%10;
				a[i]=a[i]/10;
				n=n*10+y;
			}
				b[i]=n;
		}
		System.out.println("The reversed numbers are:");
		for (int i : b) {
			System.out.println(i);
		}
		Arrays.sort(b);
		System.out.println("The sorted order is:");
		for (int j : b) {
			System.out.println(j);
		}
}
}


/*int yrr[]={1,2,3,4,5};
Array.sort(yrr);*/
