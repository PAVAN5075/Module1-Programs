package sorting;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Squres {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map <Integer, Integer>sq= new HashMap<Integer, Integer>();
		Scanner sc=new Scanner(System.in);
		Integer n=sc.nextInt();
		Integer s[]= new Integer [n];
		Integer c[]= new Integer [n];
		Scanner sc1= new Scanner(System.in);
		for(int i=0;i<n;i++){
			sq.put(s[i]=sc1.nextInt(),c[i]=getSqures(s[i]));
		}
		for(int i = 0;i<n;i++){
			System.out.println(s[i] +":"+c[i]);
		}
	}
	public static Integer getSqures(int a) {
		return a*a;
	}
}

