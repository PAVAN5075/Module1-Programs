package sorting;

public class replacing {

	public replacing() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Abcd";
		char ch1[]=s1.toCharArray();
		String s2="Dcba";
		char ch2[]=s2.toCharArray();
		int l1=s1.length();
		int l2=s2.length();
		for (char i : ch1) {
			System.out.print(i);
		}
		System.out.println("");
		for (char i : ch2) {
			System.out.print(i);
		}

		for (int i = 0; i < l1; i++) {
			for (int j = 0;j <l2; j++) {
				if (ch1[i]==ch2[j]) {
					ch1[i]='*';
					ch2[j]='*';
				}
			}
		}
		System.out.println("");
		for (char i : ch1) {
			System.out.print(i);
		}
		System.out.println("");
		for (char i : ch2) {
			System.out.print(i);
		}
	}

}
