package sorting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class concat {

	public concat() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="abcdefgh";
		int l=s1.length();
		List<String> list2= Arrays.asList(s1);
		/*ArrayList<Character> list1=new ArrayList<Character>();
		char ch1[]=s1.toCharArray();
		for (int i = 0; i < ch1.length/2; i++) {
			list1=ch1[i];
		}
		for (int i = ch1.length/2; i < ch1.length; i++) {
			
		}*/
		System.out.println(list2);
	}

}
