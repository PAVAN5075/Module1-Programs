package sorting;

import java.util.ArrayList;
import java.util.List;
public class addremove {

	public addremove() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list2=new ArrayList<Integer>();
		list2.add(1);
		list2.add(12);
		list2.add(123);
		list2.add(1234);
		
		List list=new ArrayList();
		list.add(1);
		list.add("KPS");
		list.add('M');
		list.add(12.34);
		list.add(true);
		list.addAll(list2);
		
		System.out.println(list);
		
		list.removeAll(list2);
		System.out.println(list);
	}

}
