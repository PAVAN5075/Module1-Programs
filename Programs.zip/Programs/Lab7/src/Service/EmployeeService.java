package Service;

import java.util.Collection;

import sorting.Employee;

public interface EmployeeService {
	int addEmployee(Employee emp);
	Collection<Employee> getEmployeeByInsurancce(String insurance);
	boolean deleteEmployee(int id);
}