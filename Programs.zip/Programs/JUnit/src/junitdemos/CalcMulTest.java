package junitdemos;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalcMulTest {

	@Test
	public void test() {
		Calc c= new Calc();
		assertEquals(36, c.mul(6, 6));
	}

}
