package junitdemos;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class CalcTest {

	
	Calc c;
	@Before
	public void init(){
		c=new Calc();
		System.out.println("Before Method");
	}
	
	@Test
	public void testAdd() {
		//Calc c= new Calc();
		assertEquals(12, c.add(6, 6));
	}
	
	//@Ignore("This method is not completed yet")
	@Test
	public void testSub() {
		//Calc c= new Calc();
		assertEquals(12, c.sub(14, 2));
	}
	
	@After
	public void windUp(){
		System.out.println("WindUp Method");
	}
	
	@BeforeClass
	public void beforeAll(){
		System.out.println("BeforeAll Class");
	}
	
	@AfterClass
	public void afterAll(){
		System.out.println("AfterAll Class");
	}
	
}
