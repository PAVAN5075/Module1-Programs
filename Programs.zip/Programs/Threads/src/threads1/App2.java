package threads1;

public class App2 {

	public static void main(String[] args) {
	
		System.out.println("Main Starts . . .");
		Thread t1=new Thread(new Runner(),"First");
		Thread t2=new Thread(new Runner(),"Second");
		t1.start();
		t2.start();
		t1.setPriority(7);
		System.out.println("Priority: "+t1.getPriority());
		System.out.println("Priority: "+t2.getPriority());
		try {
			//t1.join(200);
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Main Ends . . .");

	}

}
class Runner implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<25;i++){
			System.out.println(i+"-"+Thread.currentThread().getName());
			try {
				Thread.sleep(700);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}