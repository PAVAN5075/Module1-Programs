package threads1;

public class App extends Thread {

	@Override
	public void run() {
		for(int i=0;i<25;i++){
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		super.run();
	}

	public static void main(String[] args) {
		App a= new App();
		App b=new App();
		System.out.println("Main Starts");
		a.start();
		b.start();
		System.out.println("Main Ends");

	}
}
