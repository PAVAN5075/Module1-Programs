package threads1;

import java.util.LinkedList;

public class ProdrucerConsumer {
	private LinkedList<Integer> list = new LinkedList<Integer>();
	private final int LIMIT=10;
	private Object lock=new Object();
	public void producer() throws InterruptedException{
		int value=0;
		while(true){
			synchronized (lock) {
				if(list.size()==LIMIT){
					lock.wait();
				}
				notify();
				list.add(value++);
			}
			
		}
	}
	

void consume() throws InterruptedException{
	while(true){
		synchronized (lock) {
		if(list.size()==LIMIT){
			lock.wait();
		}
		notify();
	}
		System.out.println("List Size is: "+list.size());
		int value =list.removeFirst();
		System.out.println("Value is: "+value);
	}
}
}