package threads1;

public class App4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProdrucerConsumer p=new ProdrucerConsumer();
		Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					p.producer();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					p.consume();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
	t1.start();
	t2.start();
	}

}
