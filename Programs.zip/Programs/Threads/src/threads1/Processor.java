package threads1;

import java.util.Scanner;

public class Processor {
	public void produce() throws InterruptedException{
		System.out.println("Producer Srarted");
		synchronized (this) {
			System.out.println("Releasing Lock");
			wait();
			System.out.println("Producer Resumed. . .");
		}
	}
	
	public void consume() throws InterruptedException{
		System.out.println("Consumer Started");
		synchronized (this) {
			Scanner scan=new Scanner(System.in);
			System.out.println("Waiting for Return Key");
			scan.nextLine();
			notify();
			System.out.println("Return Key pressed");
		}
	}
}
