package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee E1=new Employee();
		EmployeeService i2=new EmployeeServiceImpl();
		
		E1.setDesig("Pro");
		E1.setId(1234);
		E1.setName("KPS");
		E1.setSalary(30034.56f);
	i2.InsuranceScheme(E1);
	System.out.println("Name: "+E1.getName());
	System.out.println("Disignation: "+E1.getDesig());
	System.out.println("ID: "+E1.getId());
	System.out.println("Salary: "+E1.getSalary());
	}

}
