package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public void InsuranceScheme(Employee E1) {
		// TODO Auto-generated method stub
		System.out.println("Disignation: "+E1.getDesig());
		System.out.println("Salary: "+E1.getSalary());
		if((E1.getSalary()<20000 && E1.getSalary()>5000) && E1.getDesig()=="SysEngg")
		System.out.println("C - Scheme");
		else if((E1.getSalary()>=20000 && E1.getSalary()<40000) && E1.getDesig()=="Pro")
			System.out.println("B - Scheme");
		else if(E1.getSalary()>=40000 && E1.getDesig()=="Mngr")
			System.out.println("A - Scheme");
		else
			System.out.println("No Scheme");

	}
	

}
