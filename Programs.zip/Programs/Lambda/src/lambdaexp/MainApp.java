package lambdaexp;

interface MaxFinder{
	//int maximum(int num1, int num2);
	//int squre(int n);
	void display();
}

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//MaxFinder m=(x,y)->x>y?x:y; // -----> Lambda Expression 2 param
		//MaxFinder m=(x)->x*x; //---> 1 param
		MaxFinder m=()->{System.out.println("Hello");}; //---> no param
	}

}
