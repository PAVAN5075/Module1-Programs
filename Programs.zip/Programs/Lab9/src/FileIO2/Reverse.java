package FileIO2;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reverse {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 FileReader fr=new FileReader("C:/Users/pkomarra/Desktop/Source.txt");
		 FileWriter fw=new FileWriter("C:/Users/pkomarra/Desktop/Source1.txt");
		StringBuilder sb=new StringBuilder();
		int c;
		while((c=fr.read())!=-1){
			sb.append((char)c);
			
		}
		
		sb.reverse();
		System.out.print(sb);
		String s=sb.toString();
		fw.write(s);
		fw.flush();
	}
	
}
