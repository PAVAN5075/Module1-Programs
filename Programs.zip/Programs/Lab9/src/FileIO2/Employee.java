 package FileIO2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Employee {
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", Designation=" + Designation + ", Insurancescheme="
				+ Insurancescheme + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getInsurancescheme() {
		return Insurancescheme;
	}

	public void setInsurancescheme(String insurancescheme) {
		Insurancescheme = insurancescheme;
	}

	int id;
	String name;
	double salary;
	String Designation;
	String Insurancescheme;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		List<Employee> list=new ArrayList<Employee>();
		Employee e1=new Employee();
		e1.setId(1001);
		e1.setName("Abc");
		e1.setSalary(45000);
		e1.setDesignation("Manager");
		e1.setInsurancescheme("Scheme A");
		list.add(e1);
		for (Employee employee : list) {
			System.out.println(employee);
		}
		FileWriter fw=new FileWriter(("c:/Users/pkomarra/Desktop/Source.txt"));
		String s=list.toString();
		fw.write(s);
		fw.flush();
		
		
		
	}

}
