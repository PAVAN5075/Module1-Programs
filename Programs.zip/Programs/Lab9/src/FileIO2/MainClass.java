package FileIO2;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainClass {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, InterruptedException {
		
		FileInputStream fis=new FileInputStream(("c:/users/pkomarra/desktop/numbers.txt"));
		Scanner sc=new Scanner(fis);
		
		sc.useDelimiter(",");
		while(sc.hasNextInt()){
			int i= sc.nextInt();
			if(i%2==0){
				System.out.println(i);
			}
		}
	}

}
