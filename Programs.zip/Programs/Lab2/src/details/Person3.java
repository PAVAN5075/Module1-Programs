package details;

public class Person3 {
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	String FirstName,LastName;
	char Gender;
	int PhoneNumber;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person3 P3=new Person3();
		P3.setFirstName("Pavan");
		P3.setLastName("K");
		P3.setGender('M');
		P3.setPhoneNumber(1234567);
		System.out.println("First Name: "+P3.getFirstName());
		System.out.println("Last Name:"+P3.getLastName());
		System.out.println("Gender: "+P3.getGender());
		System.out.println("Phone Number: "+P3.getPhoneNumber());

	}

}
