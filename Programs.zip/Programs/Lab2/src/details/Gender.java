package details;

public enum Gender {
	M,F;
}
