package details;

public class PersonMain {

public PersonMain(String firstName, String lastName, char gender) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}

String FirstName,LastName;
char Gender;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonMain P1=new PersonMain("Pavan", "K", 'M');
		System.out.println(P1.FirstName);
		System.out.println(P1.LastName);
		System.out.println(P1.Gender);
	}
}
