package details;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First Name:"+args[0]);
		System.out.println("Last Name:"+args[1]);
		System.out.println("Gender:"+args[2]);
		System.out.println("Age:"+args[3]);
		System.out.println("Weight:"+args[4]);
		int age=Integer.parseInt(args[3]);
		if(age>0){
		System.out.println("Positive Number");
		}
		else{
		System.out.println("First Name:"+args[0]);
		}
	}

}
