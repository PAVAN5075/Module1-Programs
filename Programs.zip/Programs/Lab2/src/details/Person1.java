package details;

public class Person1 {
	String Firstname, Lastname;
	char Gender;
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person1 P1=new Person1();
		P1.setFirstname("Pavan");
		P1.setLastname("K");
		P1.setGender('M');
		System.out.println("First Name: "+P1.getFirstname());
		System.out.println("Last Name:"+P1.getLastname());
		System.out.println("Gender: "+P1.getGender());
	}

}
