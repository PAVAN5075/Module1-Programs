package details;

public class Person2 {
	String Firstname, Lastname;
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person2 P2=new Person2();
		P2.setFirstname("Pavan");
		P2.setLastname("K");
		Gender G1=Gender.M;
		System.out.println("First Name: "+P2.getFirstname());
		System.out.println("Last Name:"+P2.getLastname());
		System.out.println("Gender: "+G1);
	}
}
