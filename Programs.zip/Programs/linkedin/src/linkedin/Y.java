package linkedin;

public class Y extends X {
	int a,b;
	public Y(){
		System.out.println("Y Default Constructor");
	}
	public Y(int a,int b){
		System.out.println("Y Parameterised Constructor");
		this.a=a;
		this.b=b;
	}
	/*public void print(){
		System.out.println(this.x);
		System.out.println(this.y);
	}*/
	
}
