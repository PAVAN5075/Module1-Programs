package linkedin;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Y y=new Y(12,45);
		System.out.println(y.a);
		System.out.println(y.b);	}

}
