package linkedin;

public class Son extends Father {
	String atmPassword;
	public void dream5(){
		System.out.println("own CG");
	}
	public void dream(float amount){
		System.out.println("Dream Son Amount"+(amount/2));
	}
	
}
