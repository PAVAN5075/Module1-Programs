package linkedin;

public class Mainq {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Son s=new Son();
		s.dream5();
		s.dream();
		s.dream("qwrbgf");
		Father f=new Father();
		f.dream();
		f.dream("Pwdfh");
		f.dream(121.34f);
	}

}
