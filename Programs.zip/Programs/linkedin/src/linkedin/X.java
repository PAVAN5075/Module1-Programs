package linkedin;

public class X {
	int x,y;
	final String name="CG";	
	public X(){
		System.out.println("X Default Constructor");
	}
	public X(int a,int b){
		System.out.println("X Parameterised Constructor");
		
	}
	
	public void print(){
		this.x=x;
		this.y=y;
		System.out.println(this.x);
		System.out.println(this.y);
	}
}
