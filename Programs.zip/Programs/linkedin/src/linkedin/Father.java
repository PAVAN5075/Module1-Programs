package linkedin;

public class Father {
	public void dream(){
		System.out.println("drean()");
	}
	public void dream(String son){
		System.out.println("Dream with"+son);
	}
	public void dream(float amount){
		System.out.println("Dream with"+amount);
	}
}
