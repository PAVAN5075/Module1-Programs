package Collections;

public class Employee {

		String name,email,phone,companyName;
		int id;
		public Employee(String name, String email, String phone, String companyName, int id) {
			super();
			this.name = name;
			this.email = email;
			this.phone = phone;
			this.companyName=companyName;
			this.id = id;
		}
		
		@Override
		public int hashCode() {
			return id;
		}
		@Override
		public boolean equals(Object obj) {
			boolean flag=false;
			Employee e=(Employee)obj;
			Employee current=this;
			if(e.email.equals(current.email) && e.companyName.equals(current.companyName)){
				flag=true;
			}
			return flag;
		}	
}
