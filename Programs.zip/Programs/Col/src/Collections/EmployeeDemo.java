package Collections;

public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee("Pavan", "pavan50756@gmail.com", "9841339819", "CapGemini", 152845);
		System.out.println(e1.hashCode());
		Employee e2=new Employee("Pavan1", "pavan507562@gmail.com", "98413398193", "CapGemini4", 1528455);
		System.out.println(e2.hashCode());
		System.out.println(e1.equals(e2));
	}

}
