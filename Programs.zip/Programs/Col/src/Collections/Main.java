package Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> nameset=new HashSet<String>();
		Vector<Integer> v=new Vector<Integer>();
		v.add(12);
		v.addElement(456);
		v.remove(0);
				
				
		nameset.add("Pa");
		nameset.add("Pa");
		nameset.add("va");
		nameset.add("n");
		
		System.out.println(nameset);
		for (Iterator<String> iterator = nameset.iterator(); iterator.hasNext();) {
			String string = iterator.next();
			
		}
	}

}
