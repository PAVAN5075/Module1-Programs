package Collections;

import java.util.TreeSet;

public class TreeSetDemo {

	public TreeSetDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Student> ts=new TreeSet<Student>();
		ts.add(new Student("1","A"));
		ts.add(new Student("2","B"));
		System.out.println(ts);
		
		TreeSet<Person> tsp=new TreeSet<Person>(new Person("",""));
		
		tsp.add(new Person("1","A"));
		tsp.add(new Person("2","B"));
		System.out.println(tsp);
	}

}
