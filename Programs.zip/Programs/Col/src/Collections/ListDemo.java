package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class ListDemo {

	public ListDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> l=new ArrayList<Integer>();
		l.add(123);
		l.add(1234);
		l.add(12345);
		System.out.println(l);
		
		ArrayList<Integer> l2=new ArrayList<Integer>();
		l2.add(123);
		l2.add(1234);
		l2.add(12345);
		l2.add(123456);
		l2.add(1234567);
		System.out.println(l2);
		
		l.retainAll(l2);
		System.out.println(l);
		
		l.addAll(l2);
		System.out.println(l);
		
		int val=l.get(0);
		l.remove(0);
		System.out.println(l.isEmpty());
		HashSet<Integer> hs=new HashSet<Integer>();
		hs.addAll(l);
		System.out.println("List as a set without duplicates");
		
		
	}

}
