package com.capgemini.lesson20.thread;

public class HelloMain {

	public static void main(String[] args) {
		
		
		HelloThread hello = new HelloThread();
		hello.start();

	}

}
