package com.capgemini.lesson20.mockdemo;

public class User {
String username, password;
}
