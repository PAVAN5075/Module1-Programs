package com.capgemini.lesson6.useoffinal;

public final class Base {

	public Base()
	{
		System.out.println("Constructor in class BASE");
	}
}
