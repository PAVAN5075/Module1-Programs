package com.capgemini.lesson14;


public class Greeting {
	public String greet()
	{
		return "WELCOME TO JAVA";
	}
}
